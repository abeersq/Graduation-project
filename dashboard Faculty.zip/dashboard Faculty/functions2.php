<?php
include("dbConn.php");
session_start();

function Calendar($TaskName,$deadline,$Deliverable){


    global $conn;
  $sql = "INSERT INTO SCHEDULE (TaskName,deadline,Deliverable) VALUES ('".$TaskName."', '".$deadline."', '".$Deliverable."')";

if ($conn->query($sql) === TRUE) {
     $_SESSION['Calendar'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}


function Guideline($version,$Type){

    global $conn;
  $sql = "INSERT INTO Guideline (version,Type) VALUES ('".$version."', '".$Type."')";

if ($conn->query($sql) === TRUE) {
     $_SESSION['Guideline'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}




function AddGPfiles($Title,$Abstract,$Grade,$GPfile,$P_Keyword){

    global $conn;

  $sql1 = "INSERT INTO Project_Archive (Title,Abstract,Grade,GPfile) VALUES ('".$Title."', '".$Abstract."','".$Grade."','".$GPfile."')";
  $sql2 = "INSERT INTO Keyword (P_Keyword) VALUES ('".$P_Keyword."')";


if ($conn->multi_query($sql1) === TRUE) {
     $_SESSION['AddGPfiles'] = true;
     alert(false,"Added Successfuly ..");
 } else {
  alert(true,"Erorr ..");
}

if ($conn->multi_query($sql2) === TRUE) {
     $_SESSION['AddGPfiles'] = true;

 } else {
  alert(true,"Erorr ..");
}

$conn->close();
}


function updateGPCInfo($id,$NAME,$Email,$PASSWORD){
    global $conn;
    $sql = " UPDATE Faculty SET
     NAME='".$NAME."',
     Email='".$Email."'
     Password='".$PASSWORD."',
     WHERE id='".$id."'";
$conn->query($sql);
if ($conn->affected_rows > 0) {
    alert(false,"Update Successfuly ..");
}
else if ($conn->affected_rows <= 0) {
    alert(true," Cant update !! ");
}
else {
    $msg = "Erroe ..!! " . $conn->error;
    alert(true,$msg);
}

$conn->close();
}



function alert($isError,$msg){
    if($isError){
      echo '<div class="alert alert-danger mt-5 " role="alert">'.$msg.'</div>';
    }
    else{
        echo '<div class="alert alert-success mt-5 " role="alert">'.$msg.'</div>';
    }
}


?>
