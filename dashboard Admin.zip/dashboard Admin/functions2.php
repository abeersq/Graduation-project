<?php
include("dbConn.php");

function Calendar($TaskName,$deadline,$Deliverable){


    global $conn;
  $sql = "INSERT INTO SCHEDULE (TaskName,deadline,Deliverable) VALUES ('".$TaskName."', '".$deadline."', '".$Deliverable."')";

if ($conn->query($sql) === TRUE) {
     $_SESSION['loggedin'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}


function Guideline($version,$Type){

    global $conn;
  $sql = "INSERT INTO Guideline (version,Type) VALUES ('".$version."', '".$Type."')";

if ($conn->query($sql) === TRUE) {
     $_SESSION['loggedin'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}




function AddGPfiles($Title,$Abstract,$Grade,$GPfile,$P_Keyword){

    global $conn;

  $sql1 = "INSERT INTO Project_Archive (Title,Abstract,Grade,GPfile) VALUES ('".$Title."', '".$Abstract."','".$Grade."','".$GPfile."')";
  $sql2 = "INSERT INTO Keyword (P_Keyword) VALUES ('".$P_Keyword."')";


if ($conn->multi_query($sql1) === TRUE) {
     $_SESSION['AddGPfiles'] = true;
     alert(false,"Added Successfuly ..");
 } else {
  alert(true,"Erorr ..");
}

if ($conn->multi_query($sql2) === TRUE) {
     $_SESSION['AddGPfiles'] = true;

 } else {
  alert(true,"Erorr ..");
}

$conn->close();
}


function deletefaculty($email){
    global $conn;
$sql = "DELETE FROM Faculty WHERE Email='".$email."'";
$result=$conn->query($sql);
if($conn->affected_rows > 0){
//if ($conn->query($sql) === TRUE) {
alert(false,"User Deleted");
} else {
alert(true,"Error Email does not exist");
}

$conn->close();
}





function deleteStudent($email){
    global $conn;
$sql = "DELETE FROM student WHERE Email='".$email."'";
$result=$conn->query($sql);
if($conn->affected_rows > 0){
//if ($conn->query($sql) === TRUE) {
     alert(false,"User Deleted");
} else {
    alert(true,"Error Email does not exist");
}

$conn->close();
}




function deleteGPCommittee($email){
    global $conn;
$sql = "DELETE FROM GP_committee WHERE Email='".$email."'";
$result=$conn->query($sql);
if($conn->affected_rows > 0){
//if ($conn->query($sql) === TRUE) {
alert(false,"User Deleted");
} else {
alert(true,"Error Email does not exist");
}

$conn->close();
}


function deleteGPFile($Title){
    global $conn;
$sql = "DELETE FROM Project_Archive WHERE Title='".$Title."'";
$result=$conn->query($sql);
if($conn->affected_rows > 0){
//if ($conn->query($sql) === TRUE) {
alert(false,"Project Deleted");
} else {
alert(true,"Error Project does not exist");
}

$conn->close();
}

function DeleteGroupinitiall($Group_no){
    global $conn;
$sql = "DELETE FROM  StudentInitialGroup WHERE Group_no='".$Group_no."'";
$sql2 = "DELETE FROM Group_ WHERE Group_no='".$Group_no."'";
$sql3 = "DELETE FROM  studentprojects WHERE Group_no='".$Group_no."'";
$result=$conn->query($sql);
$result2=$conn->query($sql2);
$result3=$conn->query($sql3);

if($conn->affected_rows > 0){
//if ($conn->query($sql) === TRUE) {
alert(false,"Group Deleted");
} else {
alert(true,"Error Group does not exist");
}

$conn->close();
}




function updateGPCInfo($Email2,$NAME,$Email,$PASSWORD){
    global $conn;
    $sql = " UPDATE GP_committee SET
     Name='".$NAME."',
     Email='".$Email."'
     Password='".$PASSWORD."',
     WHERE Email='".$Email2."'";
$conn->query($sql);
if ($conn->affected_rows > 0) {
    alert(false,"Update Successfuly ..");
}
else if ($conn->affected_rows <= 0) {
    alert(true," Cant update !! ");
}
else {
    $msg = "Erroe ..!! " . $conn->error;
    alert(true,$msg);
}

$conn->close();
}




function alert($isError,$msg){
    if($isError){
      echo '<div class="alert alert-danger mt-5 " role="alert">'.$msg.'</div>';
    }
    else{
        echo '<div class="alert alert-success mt-5 " role="alert">'.$msg.'</div>';
    }
}



?>
