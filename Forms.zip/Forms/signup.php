<!DOCTYPE html>
<?php
include("functions.php");


if (!empty($_POST))
if (isset($_POST['submit'])){

$NAME= $_POST['UserName'];
$email= $_POST['Email'];
$PASSWORD= $_POST['Password'];
$type= $_POST['type'];

 SignUp($NAME,$email,$PASSWORD,$type);
}
 ?>


 <html>
 <head>
   <title>Sign Up</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link href="https://fonts.googleapis.com/css?family=Slabo+27px&display=swap" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="/gp/Homepagesection.css">
 <style type="text/css">

   body{
     margin: 19px ;
     padding: 0;
     justify-content: center;
     display: block;
     margin-right: 325px;
   }

 </style>
 </head>
 <body>

 <div style="align-items:center;">
 <div class="navbar">
   <img src="https://imgur.com/uxfkTWY" alt="logo1" >
   <img src="https://imgur.com/AR0TosG" alt="logo2" style="margin-right:15%;" >
   <a href="#MyProfile">MyProfile</a>
   <a href="/gp/Homepagesection1.php">Home</a>
   <a href="#GpFile">Gp File</a>
   <img src="https://i.imgur.com/atzKUZU.png" alt="Graduation logo"style="width:60px ;height: 60px;">
   <a href="#AboutUs">About Us</a>
   <a href="mailto:cs.gp.f@imamu.edu.sa">Contact Us</a>
   <a href="Forms/login.php">Login</a>
   </div>
 </div>

   <h2>SignUp </h2>

   <div class="signup">
     <form method="post" action="signup.php">

 <label >Email: <span style="color:#9f0000;" >*</span></label><br><br>
       <input type="Email" name="Email" id="Email" required placeholder="Imam Email Id "><br>

     <label >User Name : <span style="color:#9f0000;" >*</span></label><br><br>
       <input type="text" name="UserName" id="UserName" required placeholder="Imam User ID "><br>

       <label>Password : <span style="color:#9f0000;" >*</span></label><br><br>
       <input type="Password" name="Password" id="Password" required><br>
        <!--- <button type="button">Sign in</button>---->
        <label >User type : <span style="color:#9f0000;" >*</span></label><br><br>
        <input type="radio" name="type" value="1"> GP commmittee.<br>
        <input type="radio" name="type" value="2"> Supervisor.<br>
        <input type="radio" name="type" value="3"> Student.<br>

      <div class="signup-btn">
      <a href="/gp/Homepagesection.php"><input type="submit" name="submit" value="Sign Up"></a>
     </div>

       </form>
   </div>

 <div class="pic"> <img src="https://i.imgur.com/6IvVYIC.png" alt="login_pic" ></div>
 </body>
 </html>
