<?php include("functions.php");
session_start();
 ?>

 <html>
 <head>
   <title>Login Page</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link href="https://fonts.googleapis.com/css?family=Slabo+27px&display=swap" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="/gp/Homepagesection.css">
 <style type="text/css">

   body{
     margin: 19px ;
     padding: 0;
     justify-content: center;
     display: block;
     margin-right: 325px;

   }

 </style>
 </head>
 <body>

 <div style="align-items:center;">
 <div class="navbar">
   <img src="imam logo.jpg" alt="logo1" >
   <img src="imam logo2.jpg" alt="logo2" style="margin-right:15%;" >
   <a href="#MyProfile">MyProfile</a>
   <a href="/gp/Homepagesection1.php">Home</a>
   <a href="#GpFile">Gp File</a>
   <img src="https://i.imgur.com/atzKUZU.png" alt="Graduation logo"style="width:60px ;height: 60px;">
   <a href="#AboutUs">About Us</a>
   <a href="mailto:cs.gp.f@imamu.edu.sa">Contact Us</a>

   </div>
 </div>
