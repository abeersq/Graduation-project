<?php
include("dbConn.php");

function SignUp($NAME,$email,$PASSWORD,$type){


    global $conn;

    if ($type == 1){
      $sql = "INSERT INTO GP_committee (NAME,Email,password) VALUES ('".$NAME."', '".$email."', '".$PASSWORD."')";

    } elseif ($type == 2){
      $sql = "INSERT INTO Faculty (NAME,Email,password) VALUES ('".$NAME."', '".$email."', '".$PASSWORD."')";

    } elseif ($type == 3){
      $sql = "INSERT INTO Student (NAME,Email,password) VALUES ('".$NAME."', '".$email."', '".$PASSWORD."')";
    }


if ($conn->query($sql) === TRUE) {

     $_SESSION['Signup'] = true;
     $_SESSION['Name'] = $NAME;

    echo "Registration Successful";

} else {
    $msg= "Registration Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}



function login($email , $PASSWORD){

    global $conn;
    $sql ="select NAME from GP_committee where email='".$email."' and password='".$PASSWORD."'";
    $result = $conn->query($sql);


    if ($result->num_rows === 1) {
        //Current user is in Admin table, hence he/she is an admin
        $_SESSION['loggedin'] = true;
        $_SESSION['Name'] = $NAME;
        header("location:/gp/dashboard Admin/index.php");
        exit(0);
    } elseif ($result->num_rows > 1) {
          //there should not be more than one rows with same credentials. Two rows with same (username, password), Make username primary key.
          throw new Exception("Multiple entry with same username and password in admin table");
    } else {
        //Given credentials are not in admin table, check user table.
        $sql1 ="select NAME from faculty where email='".$email."' and password='".$PASSWORD."'";
        $result1 = $conn->query($sql1);

        if ($result1->num_rows === 1) {
          $_SESSION['loggedin'] = true;
          $_SESSION['Name'] = $NAME;
          header("location:/gp/dashboard Faculty/index.php");
        } elseif ($result1->num_rows > 1) {
            throw new Exception("Multiple entry with same username and password in user table");
        }
        else {
          //Given credentials are not in admin table, check user table.
          $sql2 ="select NAME from student where email='".$email."' and password='".$PASSWORD."'";
          $result2 = $conn->query($sql2);

          if ($result2->num_rows === 1) {
            $_SESSION['loggedin'] = true;
            $_SESSION['Name'] = $NAME;
            header("location:/gp/dashboard Faculty/index.php");
          } elseif ($result2->num_rows > 1) {
              throw new Exception("Multiple entry with same username and password in user table");
          }
        }


    }

    $conn->close();
}

function contact($NAME,$email,$textc){


    global $conn;
    $sql = "INSERT INTO ContactForm (name,email,textc) VALUES ('".$NAME."', '".$email."', '".$textc."')";

if ($conn->query($sql) === TRUE) {
    echo "thank you..";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}

function facultyform( $NAME, $phoneNumber, $OfficeNumber, $OfficeHour, $ProjectType, $CSAreas_fields,	$ProjectTitle, $Abstract,	$SkillsEquipment,	$email){


    global $conn;
    $sql = "INSERT INTO facultyform (NAME,phoneNumber,OfficeNumber,OfficeHour,ProjectType,CSAreas_fields,ProjectTitle,Abstract,SkillsEquipment,email)
    VALUES ('".$NAME."', '".$phoneNumber."', '".$OfficeNumber."', '".$OfficeHour."', '".$ProjectType."', '".$CSAreas_fields."',	'".$ProjectTitle."', '".$Abstract."',	'".$SkillsEquipment."','".$email."')";

if ($conn->query($sql) === TRUE) {
echo "Thank you..!";
} else {
    $msg= "Error" . $conn->error;
echo $msg;
}

$conn->close();
}

function studentform($GPA,$ID,$Student_email){


    global $conn;
    $sql = "INSERT INTO Student (GPA,ID,Student_email,Group_no) VALUES ('".$GPA."', '".$ID."', '".$Student_email."')";


if ($conn->query($sql) === TRUE) {
    echo "thank you..";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}

?>
