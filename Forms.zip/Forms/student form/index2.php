<!DOCTYPE html>

<?php
include("functions.php");

if (!empty($_POST))
if (isset($_POST['submit'])){



$Project1=$_POST['project1'];
$Project2=$_POST['project2'];
$Project3=$_POST['project3'];
$Project4=$_POST['project4'];
$Project5=$_POST['project5'];

studentproject($Project1,$Project2,$Project3,$Project4,$Project5);
header("location:/gp/Homepagesection1.php");

}
 ?>

 <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form</title>

    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <style type="text/css">
        .form-datalist{
            width: 60%;
/*  padding: 11px 20px;
  box-sizing: border-box;
  font-family: 'Montserrat';
  font-weight: 500;
  font-size: 13px; */}
        }
    </style>
</head>
<body>

    <div class="main">
        <div class="container"style="border-radius: 10px; box-shadow: 0px 4px 14px rgb(0,0,0,0.9);">
            <div class="content">
                            <!----img src="image/file-searching.jpg" alt="pic" style="padding: 9px;margin: 11px;float: right; box-sizing: content-box;width: 540px;height: 481px;"--------------->

                <div class="form">
                    <form method="POST" action="index2.php" class="register-form" id="register-form">
                        <h2>student registration form</h2>


                        <div class="form-group">
                            <label for="course">Graduation Project 1 :</label>
                            <div class="form-datalist">
                                <input list="Graduation Project" name="project1" required placeholder="select preferences">
  <datalist id="Graduation Project">
    <option value="Graduation Project 1 ">
    <option value="Graduation Project 2">
    <option value="Graduation Project 3">
    <option value="Graduation Project 4">
    <option value="Graduation Project 5">
  </datalist>
                            </div>
                        </div>



                        <div class="form-group">
                            <label for="course">Graduation Project 2 :</label>
                            <div class="form-datalist">
                                <input list="Graduation Project" name="project2" required placeholder="select preferences">
  <datalist id="Graduation Project">
    <option value="Graduation Project 1 ">
    <option value="Graduation Project 2">
    <option value="Graduation Project 3">
    <option value="Graduation Project 4">
    <option value="Graduation Project 5">
  </datalist>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="course">Graduation Project 3 :</label>
                            <div class="form-datalist">
                                <input list="Graduation Project" name="project3" required placeholder="select preferences">
  <datalist id="Graduation Project">
    <option value="Graduation Project 1 ">
    <option value="Graduation Project 2">
    <option value="Graduation Project 3">
    <option value="Graduation Project 4">
    <option value="Graduation Project 5">
  </datalist>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="course">Graduation Project 4 :</label>
                            <div class="form-datalist">
                                <input list="Graduation Project" name="project4" required placeholder="select preferences">
  <datalist id="Graduation Project">
    <option value="Graduation Project 1 ">
    <option value="Graduation Project 2">
    <option value="Graduation Project 3">
    <option value="Graduation Project 4">
    <option value="Graduation Project 5">
  </datalist>
                            </div>
                        </div>


                                   <div class="form-group">
                            <label for="course">Graduation Project 5:</label>
                            <div class="form-datalist">
                                <input list="Graduation Project" name="project5" required placeholder="select preferences">
  <datalist id="Graduation Project">
    <option value="Graduation Project 1 ">
    <option value="Graduation Project 2">
    <option value="Graduation Project 3">
    <option value="Graduation Project 4">
    <option value="Graduation Project 5">
  </datalist>
                            </div>
                        </div>
                         <div class="form-row">

                        <div class="form-group">
                        <ul class="pagination" style="float: right;">
              <li class="active" ><a href="index.php">«</a></li>
              <li><a href="index.php">1</a></li>
              <li><a href="index2.php">2</a></li>
              <li class="disabled"><a href="#">»</a></li>
            </ul></div>
            <!-- END PAGINATION -->

                        <div class="form-submit">
                            <input type="submit"  value="Reset All" class="submit" name="reset" id="reset" />
                            <input type="submit" value="Submit Form" class="submit" name="submit" id="submit" />
                        </div>
                        <!-- BEGIN PAGINATION -->
            </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script >
        (function($) {

  $('#reset').on('click', function(){
      $('#register-form').reset();
  });

})(jQuery);
    </script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
