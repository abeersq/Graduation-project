<?php
include("dbConn.php");
session_start();

function StudentForm($Name1,$Name2,$Name3,$Name4,$GPA1,$GPA2,$GPA3,$GPA4,$ID1,$ID2,$ID3,$ID4,$Email1,$Email2,$Email3,$Email4,$Semester){


    global $conn;
  $sql1 = "INSERT INTO StudentInitialGroup (Name1,Name2,Name3,Name4,GPA1,GPA2,GPA3,GPA4,ID1,ID2,ID3,ID4,Email1,Email2,Email3,Email4)
  VALUES ('".$Name1."', '".$Name2."', '".$Name3."', '".$Name4."', '".$GPA1."', '".$GPA2."', '".$GPA3."', '".$GPA4."', '".$ID1."', '".$ID2."',
    '".$ID3."', '".$ID4."', '".$Email1."', '".$Email2."', '".$Email3."', '".$Email4."')";

    $values = array($GPA1, $GPA2, $GPA3, $GPA4);
    $average = array_sum($values) / count($values);
    $sql2 = "INSERT INTO Group_ (AVG_GPA,semester) VALUES ('".$average."','".$Semester."')";

if ($conn->query($sql1) === TRUE) {
     $_SESSION['Calendar'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

if ($conn->query($sql2) === TRUE) {
     $_SESSION['Calendar'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}
$conn->close();
}


function studentproject($Project1,$Project2,$Project3,$Project4,$Project5){

    global $conn;
    $sql = "INSERT INTO studentprojects (Project1,Project2,Project3,Project4,Project5)
     VALUES ('".$Project1."', '".$Project2."','".$Project3."', '".$Project4."','".$Project5."')";




if ($conn->query($sql) === TRUE) {
     $_SESSION['Guideline'] = true;
    echo "thank you";
} else {
    $msg= "Error..!!!" . $conn->error;
    echo $msg;
}

$conn->close();
}



function alert($isError,$msg){
    if($isError){
      echo '<div class="alert alert-danger mt-5 " role="alert">'.$msg.'</div>';
    }
    else{
        echo '<div class="alert alert-success mt-5 " role="alert">'.$msg.'</div>';
    }
}


?>
