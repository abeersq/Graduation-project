<!DOCTYPE html>

<?php
include("functions.php");

if (!empty($_POST))
if (isset($_POST['submit'])){



$Name1=$_POST['StdName1'];
$Name2=$_POST['StdName2'];
$Name3=$_POST['StdName3'];
$Name4=$_POST['StdName4'];

$GPA1=$_POST['Stdgpa1'];
$GPA2=$_POST['Stdgpa2'];
$GPA3=$_POST['Stdgpa3'];
$GPA4=$_POST['Stdgpa4'];

$ID1= $_POST['Stdid1'];
$ID2=$_POST['Stdid2'];
$ID3=$_POST['Stdid3'];
$ID4=$_POST['Stdid4'];

$Email1=$_POST['StdEmail1'];
$Email2=$_POST['StdEmail2'];
$Email3=$_POST['StdEmail3'];
$Email4=$_POST['StdEmail4'];

$Semester=$_POST['Semester'];

StudentForm($Name1,$Name2,$Name3,$Name4,$GPA1,$GPA2,$GPA3,$GPA4,$ID1,$ID2,$ID3,$ID4,$Email1,$Email2,$Email3,$Email4,$Semester);
header("location: index2.php");
}
 ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form</title>

    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main" >
        <div class="container" style="border-radius: 10px; box-shadow: 0px 4px 14px rgb(0,0,0,0.9);">
         <!--img src="image/file-searching.jpg" alt="pic"-->
            <div class="content">
                <div class="form">
                    <form method="POST" action="index.php" class="register-form" id="register-form">
                        <h2>student registration form</h2>
                          <p> description</p>
                          <hr>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name"> Student #1 Name :</label>
                                <input type="text" name="StdName1" id="name" required/>
                            </div></div>

                            <div class="form-row">
                            <div class="form-group">
                            <label for="id">ID :</label>
                            <input type="text" name="Stdid1" id="id" />
                        </div>
                        </div>

                        <div class="form-row">
                        <div class="form-group">
                            <label for="address">GPA :</label>
                            <input type="text" name="Stdgpa1" id="gpa" required/>
                        </div></div>
                        <div class="form-row">
                       <div class="form-group">
                                <label for="state">Email :</label>
                                <input type="text" name="StdEmail1" id="email" required/>
                            </div>
                                     </div><hr>


          <div class="form-row">
                            <div class="form-group">
                                <label for="name"> Student #2 Name :</label>
                                <input type="text" name="StdName2" id="name" required/>
                            </div></div>
                            <div class="form-row">
                            <div class="form-group">
                            <label for="id">ID :</label>
                            <input type="text" name="Stdid2" id="id" />
                        </div>
                        </div>

                        <div class="form-row">
                        <div class="form-group">
                            <label for="address">GPA :</label>
                            <input type="text" name="Stdgpa2" id="gpa" required/>
                        </div>
                    </div>
                    <div class="form-row">
                       <div class="form-group">
                                <label for="state">Email :</label>
                                <input type="text" name="StdEmail2" id="email" required/>
                            </div>
</div><hr>

                                   <div class="form-row">
                            <div class="form-group">
                                <label for="name"> Student #3 Name :</label>
                                <input type="text" name="StdName3" id="name" required/>
                            </div></div>

                            <div class="form-row">
                            <div class="form-group">
                            <label for="id">ID :</label>
                            <input type="text" name="Stdid3" id="id" />
                        </div>
                        </div>

                        <div class="form-row">
                        <div class="form-group">
                            <label for="address">GPA :</label>
                            <input type="text" name="Stdgpa3" id="gpa" required/>
                        </div></div>
                        <div class="form-row">
                       <div class="form-group">
                                <label for="state">Email :</label>
                                <input type="text" name="StdEmail3" id="email" required/>
                            </div>
</div><hr>
                                 <div class="form-row">
                            <div class="form-group">
                                <label for="name"> Student #4 Name :</label>
                                <input type="text" name="StdName4" id="name" required/>
                            </div></div>
                            <div class="form-row">
                            <div class="form-group">
                            <label for="id">ID :</label>
                            <input type="text" name="Stdid4" id="id" />
                        </div>
                        </div>

                        <div class="form-row">
                        <div class="form-group">
                            <label for="address">GPA :</label>
                            <input type="text" name="Stdgpa4" id="gpa" required/>
                        </div></div>
                        <div class="form-row">
                       <div class="form-group">
                                <label for="state">Email :</label>
                                <input type="text" name="StdEmail4" id="email" required/>
                            </div></div>

                            <hr>

                          <div class="form-row">
                            <div class="form-group">
                              <label for="address">Current Semester/Year :</label>
                              <input type="text" name="Semester" id="gpa" required/>
                            </div></div>


            <!-- END PAGINATION -->
            <div class="form-submit">
                <input type="submit"  value="Reset All" class="submit" name="reset" id="reset" />
                <input type="submit" value="Submit Form" class="submit" name="submit" id="submit" href="index2.php" />
            </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
