<!DOCTYPE html>
<?php

include("dbConn.php");
  session_start();


if (!empty($_POST))
if (isset($_POST['submit'])){

$NAME= $_POST['name'];
$email= $_POST['email'];
$textc= $_POST['textc'];

contact($NAME,$email,$textc);
}

 ?>

<html>
<head>
	<title>Contact US </title>
	<link rel="stylesheet" type="text/css" href="Homepagesection.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
   h2{
    padding: 36px;
    color: black;
    text-align: center;}
  input
    {width: 70%;
      margin-bottom: 30px;
    }
    h6{margin-top: -18px;text-decoration-color: lightblue: }
    /* contact page css*/
.contact-us{
  padding: 50px;
  margin: 232px;
  margin-top: 30px;
width: 550px;
height:550px;
box-shadow: 0px -2px 8px rgb(0,0,0,0.9);
}
   .contact-us p{
    text-align:left;
    margin:1px;
    color: black;
    text-decoration-style: bold;


   }
   .contact-us input[type=text] {
      border-radius: 10px;
      padding: 10px;
    }

    .contact-us input[type=submit]{
     border:2px solid lightblue;
      border-radius: 30px;
      background:lightblue;
      box-sizing:border-box;
      color: black;
      padding: 10px;
      text-align: center;
    }
   .contact-us-btn input[type=submit]{
      width: 40%;
      align-items: center;
      margin-left:58px;
    }

    .contact-us ::placeholder{
      color:black;
    text-align: left;
  }
 .contact-us label{
font-weight: bold;
font-size: medium;
color:lightblue;
  }


  </style>
</head>
<body>
	 <!--header-->
<div style="align-items:center;">
<div class="navbar">
  <img src="imam logo.jpg" alt="logo1" >
  <img src="imam logo2.jpg" alt="logo2" style="margin-right:15%;" >
  <a href="#MyProfile">MyProfile</a>
  <a href="#Home">Home</a>
  <a href="#GpFile">Gp File</a>
  <a href="#Borrow">Borrow</a>
  <img src="https://i.imgur.com/atzKUZU.png" alt="Graduation logo"style="width:60px ;height: 60px;">
  <a href="#AboutUs">About Us</a>
  <a href="#ContactUs">Contact Us</a>
  <a href="logintest.html">Login</a>
  </div>
</div>


  <h2> Contact US </h2>

  <div class="contact-us">
    <form method="post" action="contact.php">
<p><h4>Contact US</h4> </p>
    <i class="w3-xxlarge fa fa-user"></i>
      <input type="text" name="name" required placeholder="Your Name"><br>

<i class="w3-xxlarge fa fa-envelope-o"></i>
 <input type="text" name="email" required placeholder=" Your Email"><br>

     <textarea rows="8" cols="40" placeholder="Your Massage" name="textc"></textarea>

     <div class="contact-us-btn">
     <input type="submit" name="submit" value="Send Massage" >
		 <br>

     <h6>To more support contact :  cs.gp.f@imamu.edu.sa </h6>
    </div>
      </form>

  </div>

</body>
</html>
