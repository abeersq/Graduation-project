<!DOCTYPE html>
<?php
include("functions.php");

if (!empty($_POST))
if (isset($_POST['submit'])){


$email= $_POST['email'];
$PASSWORD= $_POST['Password'];

 login($email,$PASSWORD);
}
 ?>


 <html>
 <head>
   <title>Login Page</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link href="https://fonts.googleapis.com/css?family=Slabo+27px&display=swap" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="/gp/Homepagesection.css">
 <style type="text/css">

   body{
     margin: 19px ;
     padding: 0;
     justify-content: center;
     display: block;
     margin-right: 325px;

   }

 </style>
 </head>
 <body>

 <div style="align-items:center;">
 <div class="navbar">
   <img src="https://imgur.com/uxfkTWY" alt="logo1" >
   <img src="https://imgur.com/AR0TosG" alt="logo2" style="margin-right:15%;" >
   <a href="#MyProfile">MyProfile</a>
   <a href="/gp/Homepagesection1.php">Home</a>
   <a href="#GpFile">Gp File</a>
   <img src="https://i.imgur.com/atzKUZU.png" alt="Graduation logo"style="width:60px ;height: 60px;">
   <a href="#AboutUs">About Us</a>
   <a href="mailto:cs.gp.f@imamu.edu.sa">Contact Us</a>
   </div>
 </div>

   <h2>Login </h2>

   <div class="login">
     <form method="post" action="login.php">
     <label >email : <span style="color:#9f0000;" >*</span></label><br><br>
       <input type="email" name="email" id="email" required ><br>

       <label>Password : <span style="color:#9f0000;" >*</span></label><br><br>
       <input type="Password" name="Password" id="Password" required><br>
        <!--- <button type="button">Sign in</button>---->

      <div class="signin-btn">
       <a href="/gp/Homepagesection.php"><input type="submit" name="submit" value="Login" ></a>
     </div>

       <p>Don't have an account yet ?<a href="signup.php"> Create an account</a></p>
       </form></div>

 <div class="pic"> <img src="https://i.imgur.com/6IvVYIC.png" alt="login_pic" ></div>
 <!--<div class="logo"><img src="logo.png" alt="graduation-logo"></div>-->
 </body>
 </html>
